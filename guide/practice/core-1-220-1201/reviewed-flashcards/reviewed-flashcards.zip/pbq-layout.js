// Original visual workspaces; answer IDs stay stable so saved attempts remain valid.
window.PBQ_LAYOUT={
PBQ01:{mode:'placements',label:'Mobile workspace',groups:[
 {name:'Phone · discover and pair',art:5,fields:['f1','f2'],note:'Headset charged. Bluetooth available.'},
 {name:'Laptop · internet and desk',art:7,fields:['f3','f4'],note:'No Ethernet jack. USB-C data and Wi-Fi available.'},
 {name:'Headset · verification',art:5,fields:['f5'],note:'Confirm that both audio directions work.'}]},
PBQ02:{mode:'placements',label:'Server service inventory',groups:[
 {name:'Server A · address leases',art:1,fields:['f1'],note:'Assign client network settings.'},
 {name:'Server B · name lookup',art:1,fields:['f2'],note:'Translate names into IP records.'},
 {name:'Server C · web application',art:1,fields:['f3'],note:'Encrypted browser access over TCP.'},
 {name:'Server D · shared folders',art:1,fields:['f4'],note:'Direct-hosted Windows file sharing.'},
 {name:'Server E · administration',art:1,fields:['f5'],note:'Encrypted command-line access.'},
 {name:'Server F · mail transfer',art:1,fields:['f6'],note:'Transfer email between mail servers.'}]},
PBQ03:{mode:'network',label:'Office LAN · 192.168.40.0/24',groups:[
 {name:'Printer',art:4,fields:['f1','f2','f3','f4'],tab:'IPv4 properties',note:'Manual address required',diagnostic:'DEVICE: Office printer\nAssignment: Manual\nApproved IP: 192.168.40.20\nSubnet: 192.168.40.0/24\nGateway: 192.168.40.1\nDNS: 192.168.40.10\n\nDo not use .21: another printer already owns it.'},
 {name:'Scanner',art:4,fields:['f5'],tab:'Address policy',note:'Same lease each time',diagnostic:'DEVICE: Network scanner\nRequirement: remain a DHCP client\nRequirement: receive the same address each time\n\nChoose the appropriate DHCP policy.'},
 {name:'Laptop',art:7,fields:['f6'],tab:'IPv4 assignment',note:'Automatic settings',diagnostic:'DEVICE: Normal office laptop\nDynamic pool: 192.168.40.100–199\nRequirement: automatic network settings'},
 {name:'LAN address plan',art:3,fields:['f7'],tab:'Network classification',note:'192.168.40.x',diagnostic:'Router LAN: 192.168.40.1\nDNS: 192.168.40.10\nNetwork prefix: /24\n\nClassify the addresses used on this LAN.'}]},
PBQ04:{mode:'network',label:'DHCP / DNS service desk',groups:[
 {name:'Client A',art:0,fields:['f1'],tab:'Address diagnosis',note:'169.254.x.x',diagnostic:'Windows client A\nIPv4: 169.254.22.18\nSubnet mask: 255.255.0.0\nDefault gateway: none\nEthernet link: UP\nDHCP lease: not obtained'},
 {name:'DHCP server',art:1,fields:['f2'],tab:'Service action',note:'Service stopped',diagnostic:'DHCP service: STOPPED\nScope: free addresses available\nExisting valid leases: working\nAuthorization: restore the service'},
 {name:'Client B',art:0,fields:['f3'],tab:'DNS client settings',note:'IP works; names fail',diagnostic:'Web server by IP: reachable\nConfigured DNS: retired server\nDirect query to current internal DNS: succeeds\nDefault gateway: correct'},
 {name:'DNS server',art:1,fields:['f4','f5','f6','f7'],tab:'DNS record editor',note:'Add four records',diagnostic:'portal.office.example → IPv4 host\nv6.office.example → IPv6 host\nhelp.office.example → alias\noffice.example → mail exchange\n\nSelect one record type for each request.'}]},
PBQ05:{mode:'floor',label:'Wireless floor plan · United States',groups:[
 {name:'East access point',art:3,fields:['f1','f2'],note:'Overlaps West ch 1 and Center ch 6'},
 {name:'6E workstation',art:0,fields:['f3'],note:'Client + AP both support Wi-Fi 6E'},
 {name:'Legacy scanner',art:4,fields:['f4'],note:'Supports only 2.4 GHz'},
 {name:'Network uplink',art:2,fields:['f5','f6'],note:'Switch supports the AP’s PoE needs'}]},
PBQ06:{mode:'tabs',label:'Installation bench',groups:[
 {name:'Copper run',art:2,fields:['f1','f2'],note:'10GBASE-T · 300 ft total channel',extra:'cable'},
 {name:'Expansion card',art:8,fields:['f3','f4'],note:'PCIe x1 slot · 8P8C Ethernet socket'},
 {name:'External SSD',art:7,fields:['f5'],note:'Drive + cable 10 Gbps / computer 5 Gbps'},
 {name:'Network path',art:2,fields:['f6','f7'],note:'1 Gbps NIC → 100 Mbps switch port → 1 Gbps server',extra:'path'}]},
PBQ07:{mode:'tabs',label:'Storage controller',groups:[
 {name:'Server A',art:1,fields:['f1','f2'],note:'2 × 2 TB · survive either one drive failure',extra:'two'},
 {name:'Server B',art:1,fields:['f3','f4'],note:'4 × 2 TB · survive ANY two drive failures',extra:'four'},
 {name:'Server C',art:1,fields:['f5'],note:'RAID 10 · A/B mirrored · C/D mirrored · A failed',extra:'mirror'},
 {name:'Recovery plan',art:6,fields:['f6'],note:'Protect against accidental deletion'}]},
PBQ08:{mode:'tabs',label:'Cloud and virtual server console',groups:[
 {name:'Workload A',art:7,fields:['f1'],note:'Use the provider’s email application'},
 {name:'Workload B',art:1,fields:['f2'],note:'Deploy code; provider runs the OS/runtime'},
 {name:'Workload C',art:1,fields:['f3'],note:'Rent VMs; manage the guest OS'},
 {name:'Deployment',art:1,fields:['f4','f5'],note:'D: exclusive organizational cloud / E: linked private + public'},
 {name:'Virtual host',art:1,fields:['f6','f7'],note:'Direct-on-hardware hypervisor · 32 GB RAM',extra:'memory'}]},
PBQ09:{mode:'network',label:'Troubleshoot the office · 10.24.8.0/24',groups:[
 {name:'Workstation A',art:0,fields:['f1','f2'],tab:'IPv4 repair',note:'Local printing works',diagnostic:'IPv4 address . . . : 10.24.8.50\nSubnet mask . . . : 255.255.255.0\nDefault gateway . : 10.24.8.254\nDNS server . . . . : 10.24.8.10\n\nLocal printer: reachable\nRemote network: unreachable\nNo device uses 10.24.8.254.'},
 {name:'Workstation B',art:0,fields:['f3'],tab:'IPv4 repair',note:'Wrong subnet',diagnostic:'IPv4 address . . . : 10.24.9.51\nSubnet mask . . . : 255.255.255.0\nDefault gateway . : 10.24.8.1\nDNS server . . . . : 10.24.8.10\n\nApproved unused address: 10.24.8.51'},
 {name:'Workstation C',art:0,fields:['f4'],tab:'IPv4 repair',note:'Duplicate IP warning',diagnostic:'IPv4 address . . . : 10.24.8.30\nSubnet mask . . . : 255.255.255.0\nDefault gateway . : 10.24.8.1\nDNS server . . . . : 10.24.8.10\n\nPrinter also uses 10.24.8.30.\nApproved unused address: 10.24.8.52'},
 {name:'Network devices',art:2,fields:['f5','f6'],tab:'Device roles',note:'Router + Layer 2 switch',diagnostic:'Office network: 10.24.8.0/24\nRouter LAN: 10.24.8.1\nDNS: 10.24.8.10\nPrinter: 10.24.8.30\n\nChoose the device for each forwarding job.'}]},
PBQ10:{mode:'placements',label:'Repair bench · independent work orders',groups:[
 {name:'Printer A',art:4,fields:['f1'],note:'Internal test smears · fuser temperature error'},
 {name:'Printer B',art:4,fields:['f2'],note:'Clean internal test · PCL sent to PostScript-only printer'},
 {name:'Printer C',art:4,fields:['f3'],note:'Multiple sheets feed · worn separation pad confirmed'},
 {name:'RAID server',art:1,fields:['f4'],note:'Slot 2 failed · slot 1 healthy · backup verified'},
 {name:'Desktop drive',art:6,fields:['f5'],note:'SMART failure · readable files · no backup'}]}
};
